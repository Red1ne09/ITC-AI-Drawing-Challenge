<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;

class GameController extends Controller
{
    /**
     * Show the game page.
     */
    public function index()
    {
        return view('welcome');
    }

    /**
     * Start a new round and return a random prompt.
     */
    public function newRound(Request $request)
    {
        $prompts = config('draw_challenge.prompts');

        // Avoid selecting the same prompt consecutively if possible
        $lastPrompt = $request->session()->get('last_prompt');
        do {
            $prompt = $prompts[array_rand($prompts)];
        } while ($lastPrompt && $prompt === $lastPrompt && count($prompts) > 1);

        $request->session()->put('last_prompt', $prompt);

        return response()->json([
            'success' => true,
            'prompt' => $prompt,
        ]);
    }
}
