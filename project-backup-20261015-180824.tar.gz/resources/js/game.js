/**
 * AI Draw Challenge - Frontend Logic
 */

class DrawChallengeGame {
    constructor() {
        this.state = 'start'; // start, drawing, thinking, result, choice-made, error
        this.roundActive = false;
        this.currentPrompt = null;
        this.humanScore = 0;
        this.aiScore = 0;
        this.undoStack = [];
        this.maxUndoDepth = 20;
        this.isDrawing = false;
        this.lastPoint = null;
        this.errorOverlay = null;
        this.transitionEndListener = null;
        this.pendingAiGuessedCorrectly = null; // Stores user's choice until next round
        
        // DOM elements
        this.container = document.getElementById('game-container');
        this.startScreen = document.getElementById('start-screen');
        this.gameScreen = document.getElementById('game-screen');
        this.promptDisplay = document.getElementById('current-prompt');
        this.promptText = document.getElementById('prompt-text');
        this.instructionText = document.getElementById('instruction-text');
        this.canvas = document.getElementById('drawing-canvas');
        this.ctx = this.canvas.getContext('2d');
        this.scoreboard = {
            human: document.getElementById('human-score'),
            ai: document.getElementById('ai-score')
        };
        this.undoBtn = document.getElementById('undo-btn');
        this.clearBtn = document.getElementById('clear-btn');
        this.guessBtn = document.getElementById('guess-btn');
        this.resultCard = document.getElementById('result-card');
        this.resultHeading = document.getElementById('result-heading');
        this.resultButtons = {
            correct: document.getElementById('ai-correct-btn'),
            wrong: document.getElementById('ai-wrong-btn'),
        };
        
        // Configuration from PHP
        this.canvasWidth = parseInt(canvasWidth) || 700;
        this.canvasHeight = parseInt(canvasHeight) || 450;
        
        // Initialize
        this.init();
    }
    
    init() {
        // Set canvas size
        this.resizeCanvas();
        
        // Event listeners
        this.setupCanvasEvents();
        this.setupButtonEvents();
        this.setupWindowEvents();
        
        // Start with the start screen
        this.showStartScreen();
    }
    
    resizeCanvas() {
        // Set the canvas dimensions to match the container, but maintain aspect ratio
        const container = this.canvas.parentElement;
        const ratio = this.canvasWidth / this.canvasHeight;
        let width = container.clientWidth;
        let height = width / ratio;
        
        if (height > container.clientHeight) {
            height = container.clientHeight;
            width = height * ratio;
        }
        
        // Limit to maximum dimensions
        if (width > this.canvasWidth) {
            width = this.canvasWidth;
            height = this.canvasHeight;
        }
        
        this.canvas.width = width;
        this.canvas.height = height;
        
        // Redraw existing strokes if any
        if (this.undoStack.length > 0) {
            this.redrawFromStack();
        } else {
            this.clearCanvas();
        }
    }
    
    setupCanvasEvents() {
        // Pointer events for drawing
        this.canvas.addEventListener('pointerdown', (e) => this.startDrawing(e));
        this.canvas.addEventListener('pointermove', (e) => this.draw(e));
        this.canvas.addEventListener('pointerup', (e) => this.endDrawing(e));
        this.canvas.addEventListener('pointerleave', (e) => this.endDrawing(e));
        this.canvas.addEventListener('pointercancel', (e) => this.endDrawing(e));
        
        // Prevent scrolling when touching the canvas
        this.canvas.addEventListener('touchmove', (e) => e.preventDefault(), { passive: false });
    }
    
    setupButtonEvents() {
        // Start screen button
        document.getElementById('start-btn').addEventListener('click', () => this.startGame());
        
        // Drawing toolbar
        this.undoBtn.addEventListener('click', () => this.undo());
        this.clearBtn.addEventListener('click', () => this.clearCanvas());
        this.guessBtn.addEventListener('click', () => this.submitGuess());
        
        // Result buttons
        this.resultButtons.correct.addEventListener('click', () => this.scoreRound(true));
        this.resultButtons.wrong.addEventListener('click', () => this.scoreRound(false));
        document.getElementById('next-round-btn').addEventListener('click', () => this.nextRound());
    }
    
    setupWindowEvents() {
        window.addEventListener('resize', () => this.resizeCanvas());
    }
    
    showStartScreen() {
        this.state = 'start';
        this.hideErrorOverlay();
        this.resultCard.classList.remove('show');
        
        // If we're already showing the start screen, just reset and return
        if (!this.gameScreen.classList.contains('hidden-space')) {
            // We're showing the game screen, need to transition to start screen
            
            // Hide game screen, show start screen with transition
            this.gameScreen.classList.remove('opacity-100');
            this.gameScreen.classList.add('opacity-0');
            
            // After fade out, fully hide game screen and show start screen
            if (this.transitionEndListener) {
                this.gameScreen.removeEventListener('transitionend', this.transitionEndListener);
            }
            
            this.transitionEndListener = () => {
                // Make start screen visible and interactive FIRST
                this.startScreen.classList.remove('hidden-space');
                this.startScreen.classList.remove('opacity-0');
                this.startScreen.classList.add('opacity-100');
                // Then hide game screen
                this.gameScreen.classList.add('hidden-space');
                this.gameScreen.classList.remove('opacity-100');
                this.gameScreen.classList.add('opacity-0');
                // Clean up
                this.gameScreen.removeEventListener('transitionend', this.transitionEndListener);
                this.transitionEndListener = null;
            };
            
            this.gameScreen.addEventListener('transitionend', this.transitionEndListener);
        } else {
            // We're already showing start screen, just make sure it's fully visible
            this.startScreen.classList.remove('hidden-space');
            this.startScreen.classList.remove('opacity-0');
            this.startScreen.classList.add('opacity-100');
            this.gameScreen.classList.add('hidden-space');
            this.gameScreen.classList.remove('opacity-100');
            this.gameScreen.classList.add('opacity-0');
        }
        
        // Reset scores and state
        this.humanScore = 0;
        this.aiScore = 0;
        this.updateScoreboard();
        this.clearCanvas();
        this.undoStack = [];
    }
    
    startGame() {
        this.state = 'drawing';
        this.hideErrorOverlay();
        
        // Hide start screen, show game screen with transition
        this.startScreen.classList.remove('opacity-100');
        this.startScreen.classList.add('opacity-0');
        
        // After fade out, fully hide start screen and show game screen
        if (this.transitionEndListener) {
            this.startScreen.removeEventListener('transitionend', this.transitionEndListener);
        }
        
        this.transitionEndListener = () => {
            // Make game screen visible and interactive FIRST
            this.gameScreen.classList.remove('hidden-space');
            this.gameScreen.classList.remove('opacity-0');
            this.gameScreen.classList.add('opacity-100');
            // Then hide start screen
            this.startScreen.classList.add('hidden-space');
            this.startScreen.classList.remove('opacity-100');
            this.startScreen.classList.add('opacity-0');
            // Clean up
            this.startScreen.removeEventListener('transitionend', this.transitionEndListener);
            this.transitionEndListener = null;
            this.startRound();
        };
        
        this.startScreen.addEventListener('transitionend', this.transitionEndListener);
    }
    
    startRound() {
        this.roundActive = true;
        this.currentPrompt = null;
        this.resultCard.classList.remove('show');
        
        // Clear the canvas and reset undo stack for the new round
        this.clearCanvas();
        
        // Enable all drawing buttons immediately
        this.enableDrawing();
        
        // Fetch a new prompt from the server
        this.fetchNewPrompt();
    }
    
    fetchNewPrompt() {
        fetch('/game/new-round', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                this.currentPrompt = data.prompt;
                this.promptText.textContent = this.currentPrompt;
                this.instructionText.textContent = 'Draw this without writing the word!';
                this.enableDrawing();
            } else {
                this.showErrorOverlay('Failed to get a new prompt. Please try again.');
            }
        })
        .catch(() => {
            this.showErrorOverlay('Network error. Please try again.');
        });
    }
    
    enableDrawing() {
        this.canvas.style.cursor = 'crosshair';
        this.undoBtn.disabled = false;
        this.clearBtn.disabled = false;
        this.guessBtn.disabled = false;
    }
    
    disableDrawing() {
        this.canvas.style.cursor = 'not-allowed';
        this.undoBtn.disabled = true;
        this.clearBtn.disabled = true;
        this.guessBtn.disabled = true;
    }
    
    startDrawing(e) {
        if (!this.roundActive) return;
        
        this.isDrawing = true;
        const point = this.getPointerPosition(e);
        this.lastPoint = point;
        
        // Start a new stroke
        this.undoStack.push([]);
        this.addPointToCurrentStroke(point);
    }
    
    draw(e) {
        if (!this.isDrawing || !this.roundActive) return;
        
        const point = this.getPointerPosition(e);
        this.addPointToCurrentStroke(point);
        this.renderStroke(this.lastPoint, point);
        this.lastPoint = point;
    }
    
    endDrawing(e) {
        if (!this.isDrawing) return;
        
        this.isDrawing = false;
        this.lastPoint = null;
    }
    
    getPointerPosition(e) {
        const rect = this.canvas.getBoundingClientRect();
        const scaleX = this.canvas.width / rect.width;
        const scaleY = this.canvas.height / rect.height;
        
        return {
            x: (e.clientX - rect.left) * scaleX,
            y: (e.clientY - rect.top) * scaleY
        };
    }
    
    addPointToCurrentStroke(point) {
        if (this.undoStack.length === 0) {
            this.undoStack.push([]);
        }
        this.undoStack[this.undoStack.length - 1].push(point);
    }
    
    renderStroke(start, end) {
        this.ctx.beginPath();
        this.ctx.moveTo(start.x, start.y);
        this.ctx.lineTo(end.x, end.y);
        this.ctx.strokeStyle = '#000000'; // Black
        this.ctx.lineWidth = 2;
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';
        this.ctx.stroke();
    }
    
    redrawFromStack() {
        this.clearCanvas();
        this.undoStack.forEach(stroke => {
            if (stroke.length < 2) return;
            for (let i = 1; i < stroke.length; i++) {
                this.renderStroke(stroke[i-1], stroke[i]);
            }
        });
    }
    
    clearCanvas() {
        this.ctx.fillStyle = '#FFFFFF';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        this.ctx.strokeStyle = '#000000';
        this.ctx.lineWidth = 2;
        this.ctx.lineCap = 'round';
        this.ctx.lineJoin = 'round';
        // Clear undo stack when clearing canvas
        this.undoStack = [];
        this.updateUndoButton();
    }
    
    undo() {
        if (this.undoStack.length === 0) return;
        
        this.undoStack.pop();
        if (this.undoStack.length === 0) {
            this.clearCanvas();
        } else {
            this.redrawFromStack();
        }
        this.updateUndoButton();
    }
    
    updateUndoButton() {
        this.undoBtn.disabled = this.undoStack.length === 0;
    }
    
    isCanvasBlank() {
        // Simple check: get image data and see if all pixels are white
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imageData.data;
        for (let i = 0; i < data.length; i += 4) {
            // Check if pixel is not white (allowing for small tolerance)
            if (data[i] !== 255 || data[i+1] !== 255 || data[i+2] !== 255) {
                return false;
            }
        }
        return true;
    }
    
    async submitGuess() {
        if (!this.roundActive) return;
        
        if (this.isCanvasBlank()) {
            this.showErrorOverlay('Please draw something before submitting.');
            return;
        }
        
        this.state = 'thinking';
        this.disableDrawing();
        this.guessBtn.disabled = true;
        this.hideErrorOverlay();
        
        // Convert canvas to blob
        try {
            const blob = await new Promise(resolve => this.canvas.toBlob(resolve, 'image/png'));
            if (!blob || blob.size === 0) {
                throw new Error('Failed to create image from canvas.');
            }
            
            const formData = new FormData();
            formData.append('image', blob, 'drawing.png');
            
            const response = await fetch('/game/guess', {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success && data.guess) {
                this.showResult(data.guess);
            } else {
                this.showErrorOverlay(data.message || 'Failed to get a guess from the AI.');
            }
        } catch (error) {
            console.error('Error submitting guess:', error);
            this.showErrorOverlay(error.message || 'An error occurred while processing your drawing.');
        }
    }
    
    blobToBase64(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result.split(',')[1]);
            reader.onerror = reject;
            reader.readAsDataURL(blob);
        });
    }
    
    showResult(guess) {
        this.state = 'result';
        this.resultHeading.textContent = `The AI guesses: ${guess}`;
        this.resultCard.classList.add('show');
        this.resultButtons.correct.disabled = false;
        this.resultButtons.wrong.disabled = false;
        this.hideErrorOverlay();
    }
    
     scoreRound(aiGuessedCorrectly) {
         if (this.state !== 'result') return;
         
         // Prevent double scoring
         this.resultButtons.correct.disabled = true;
         this.resultButtons.wrong.disabled = true;
         
         // Store the user's choice for later scoring
         this.pendingAiGuessedCorrectly = aiGuessedCorrectly;
         
         
         this.nextRound()
     }
    
     nextRound() {
        // If there is a pending choice from the user, score it now
        if (this.pendingAiGuessedCorrectly !== null) {
            if (this.pendingAiGuessedCorrectly) {
                this.aiScore++;
            } else {
                this.humanScore++;
            }
            this.updateScoreboard();
            this.pendingAiGuessedCorrectly = null;
        }

        this.state = 'drawing';
        this.hideErrorOverlay();
        this.startRound();
     }
    
    showErrorOverlay(message) {
        this.state = 'error';
        this.disableDrawing();
        this.guessBtn.disabled = true;
        this.hideErrorOverlay(); // Ensure we don't have multiple overlays
        
        // Ensure the guess button is not hidden (in case it was set to display:none somewhere)
        this.guessBtn.style.display = '';

        // Create the overlay if it doesn't exist
        if (!this.errorOverlay) {
            this.createErrorOverlay();
        }
        
        // Set the message
        this.errorOverlay.querySelector('.error-overlay-message').textContent = message;
        
        // Show the overlay
        this.errorOverlay.style.display = 'flex';
    }
    
    createErrorOverlay() {
        this.errorOverlay = document.createElement('div');
        this.errorOverlay.className = 'error-overlay';
        this.errorOverlay.innerHTML = `
            <div class="error-overlay-content">
                <h3>Oops!</h3>
                <p class="error-overlay-message"></p>
                <div class="error-overlay-buttons">
                    <button id="error-cancel-btn">Cancel</button>
                    <button id="error-refresh-btn">Refresh Page</button>
                </div>
            </div>
        `;
        document.body.appendChild(this.errorOverlay);
        
        // Add event listeners to the buttons
        this.errorOverlay.querySelector('#error-cancel-btn').addEventListener('click', () => {
            this.hideErrorOverlay();
            // If we were in the middle of a round, we can continue drawing
            if (this.state === 'error' && this.roundActive) {
                this.enableDrawing();
                this.guessBtn.disabled = false;
                this.state = 'drawing';
            }
        });
        
        this.errorOverlay.querySelector('#error-refresh-btn').addEventListener('click', () => {
            window.location.reload();
        });
    }
    
    hideErrorOverlay() {
        if (this.errorOverlay) {
            this.errorOverlay.style.display = 'none';
        }
    }
    
    updateScoreboard() {
        this.scoreboard.human.textContent = this.humanScore;
        this.scoreboard.ai.textContent = this.aiScore;
        
        // Add animation class
        this.scoreboard.human.classList.add('score-change');
        this.scoreboard.ai.classList.add('score-change');
        
        // Remove animation class after animation ends
        setTimeout(() => {
            this.scoreboard.human.classList.remove('score-change');
            this.scoreboard.ai.classList.remove('score-change');
        }, 300);
    }
}

// Initialize the game when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.game = new DrawChallengeGame();
});
